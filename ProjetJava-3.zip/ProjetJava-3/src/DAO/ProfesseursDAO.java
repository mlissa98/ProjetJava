/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.cnx;
import static Controleur.Connexion.st;
import Controleur.Vector;
import java.sql.SQLException;
import java.sql.Driver;


/**
 *
 * @author Lydia et Mélissa
 */
public class ProfesseursDAO {
    private int id=0;
    private String nom ;
    private String prenom;
    
/**
 *@param id 
 *          id du professeur
 * @param nom
 *          nom du professeur
 * @param prenom
 *          prenom du professeur
 * @param type
 *          type de personne
 *    
 * @author Lydia et Mélissa
 */    
public ProfesseursDAO(int id, String nom, String prenom, boolean type){
    this.id = id;
    this.nom= nom;
    this.prenom=prenom;
    
    
}


public ProfesseursDAO(){
}
/**
 *@return id
 */ 
public int getId(){
return id;
}
/**
 *@return nom
 */ 
public String getNom(){
return nom;
}
/**
 *@return prenom
 */
public String getPrenom(){
return prenom;
}

/**
 *@param id
 * id du professeur
 */
public void setId(int id){
this.id=id;
}
/**
 *@param nom
 * non du professeur
 */
public void setNom( String nom){
this.nom=nom;
}
/**
 *@param prenom
 * prenom du professeur
 */
public void setPrenom(String prenom){
this.prenom=prenom;
}






public  void CreateProfesseurs(int id,String nom,String prenom){
        
    try{
            
            
           String n = "'"+nom+"'";
           String p = "'"+prenom+"'";
           
            System.out.println(n);
            String query="INSERT INTO PERSONNE VALUES("+id+","+n+","+p+")";
           
            cnx = connecterDB();
            st = cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("PROF bien ajouté");
            
        }
    catch( SQLException e){
            System.out.println(e.getMessage());
        }
    }

public void DeleteProfesseur(int id){
        try{
           String query="DELETE FROM PERSONNE WHERE id="+id; 
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("PROF bien supprimé");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }

public void UpdateProfesseur(int id,String nom,String prenom ){
       try{ 
           
          
           String query="UPDATE PERSONNE SET Nom='"+nom+"', Prenom='"+prenom+"' WHERE ID="+id;
           System.out.println(query);
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("PROF bien modifié");
           
       }catch(SQLException e){
           System.out.println(e.getMessage());
       }
       
       

}


/**
     *
     * @param id
     * id du professeur
     */
    public void RechercherProfesseur(int id){
    try{
        
        
        
            Vector a = new Vector();
            a.recherche_professeurs(id);
        
       
        
    }catch(SQLException e){
        System.out.println(e.getMessage());
    }
       
       
   }

}
