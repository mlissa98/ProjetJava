/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static Controleur.Connexion.cnx;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.st;
import java.sql.SQLException;

/**
 *
 * @author lyly
 */
public class RoomDAO {
    
    
    public RoomDAO()
    {};
    /**
 *@param id 
 *          id de la salle
 * @param nom
 *          nom de la salle
 * @param ecole_id
 *          id de l'ecole
 * @param niveau_id
 *          id du niveau
 *@param anneescolaire_id
 *           id de l'annee scolaire
 * @author Lydia et Mélissa
 */  
    public  void CreateRoom(int id,String nom, int ecole_id ,int niveau_id ,int anneescolaire_id){
        try{
            
            
            String n = "'"+nom+"'";
            
            String query="INSERT INTO CLASSE VALUES("+id+","+n+","+ecole_id+","+niveau_id+","+anneescolaire_id+")";
            cnx=connecterDB();
            st=cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("CLASSE bien ajoutée");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        
    }
 /**
 *@param id 
 *          id de la salle
 */  
     public  void DeleteRoom(int id){
        try{
           String query="DELETE FROM CLASSE WHERE id="+id; 
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("Classe bien supprimé");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
     
     
     
        /**
 *@param id 
 *          id de la salle
 * @param nom
 *          nom de la salle
 * @param ecole_id
 *          id de l'ecole
 * @param niveau_id
 *          id du niveau
 *@param anneescolaire_id
 *           id de l'annee scolaire
 * @author Lydia et Mélissa
 */
   public void UpdateRoom( int id,String nom, int ecole_id ,int niveau_id ,int anneescolaire_id){
       try{
           
        String n = "'"+nom+"'";
           
           String query="UPDATE CLASSE SET nom='"+n+"', id_ecole='"+ecole_id+"', id_niveau="+niveau_id+"', id_anneescolaire="+anneescolaire_id+" WHERE id="+id;
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("Classe bien modifiée");
           
       }catch(SQLException e){
           System.out.println(e.getMessage());
       }
       
       
   }
}
