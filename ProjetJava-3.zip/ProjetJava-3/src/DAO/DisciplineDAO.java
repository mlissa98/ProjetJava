/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Controleur.Vector;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.cnx;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.st;
import java.sql.SQLException;
import java.sql.Driver;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Lydia et Mélissa
 */
public class DisciplineDAO {
    
    
    
public DisciplineDAO(){
    
    
    
}










/**
 *
 * @author Lydia et Mélissa
 * @param id
 *          recoit id de la discipline
 * @param nom
 *          recoit noom de la discipline
 * 
 */
public  void CreateDiscipline(int id,String nom){
        
    try{
            
            
           String n = "'"+nom+"'";
           
           
            System.out.println(n);
            String query="INSERT INTO DISCIPLINE VALUES("+id+","+n+")";
           
            cnx = connecterDB();
            st = cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("DISCIPLINE bien ajoutée");
            
        }
    catch( SQLException e){
            System.out.println(e.getMessage());
        }
    }
/**
 *
 * 
 * @param id
 *          id de la discipline a supprimer
 * 
 * 
 */
public void DeleteDiscipline(int id){
        try{
           String query="DELETE FROM DISCIPLINE WHERE id="+id; 
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("Discipline bien supprimée");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
/**
 *
 * @author Lydia et Mélissa
 * @param id
 *          id de la discipline
 * @param nom
 *          nom de la discipline
 * 
 */
public void UpdateDiscipline(int id,String nom){
       try{ 
           
          
           String query="UPDATE Discipline SET Nom='"+nom+"' WHERE ID="+id;
           System.out.println(query);
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("DSCINPLINE bien modifié");
           
       }catch(SQLException e){
           System.out.println(e.getMessage());
       }
}

    /**
     *
     * @param id
     *          id de la discipline
     */
    public void RechercherDiscinpline(int id){
    try{
        
        
        
            Vector a = new Vector();
            a.affiche_discipline ();
        
       
        
    }catch(SQLException e){
        System.out.println(e.getMessage());
    }
       
       
   }

}
