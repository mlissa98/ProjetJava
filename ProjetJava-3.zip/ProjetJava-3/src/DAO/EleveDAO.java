/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Controleur.Vector;
import static Controleur.Connexion.cnx;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.st;
import java.sql.SQLException;


/**
 *
 * @author Lydia et Mélissa
 */
public class EleveDAO {
    private int id=0;
    private String nom ;
    private String prenom;
    
/**
 *@param id 
 *          id de l'eleve
 * @param nom
 *          nom de l'eleve
 * @param prenom
 *          prenom de l'eleve
 * @param type
 *          type de personne
 *    
 * @author Lydia et Mélissa
 */    
public EleveDAO(int id, String nom, String prenom, boolean type){
    this.id = id;
    this.nom= nom;
    this.prenom=prenom;
    
    
}


public EleveDAO(){
}
/**
 *
 *@return id
 * 
 */
public int getId(){
return id;
}
/**
 *
 * @return nom
 */
public String getNom(){
return nom;
}
/**
 *
 * @return prenom
 */
public String getPrenom(){
return prenom;
}

/**
 *
 * @param id
 * id de l'eleve
 */
public void setId(int id){
this.id=id;
}
/**
 *
 * @param nom
 * nom de l'eleve
 */
public void setNom( String nom){
this.nom=nom;
}
/**
 *
 * @param prenom
 * prenom de l'eleve
 */
public void setPrenom(String prenom){
this.prenom=prenom;
}





/**
 *@param id 
 *          id de l'eleve
 * @param nom
 *          nom de l'eleve
 * @param prenom
 *          prenom de l'eleve
 * 
 *    
 * @author Lydia et Mélissa
 */ 
public  void CreateEleve(int id,String nom,String prenom){
        
    try{
            
            
           String n = "'"+nom+"'";
           String p = "'"+prenom+"'";
           
            System.out.println(n);
            String query="INSERT INTO ELEVE VALUES("+id+","+n+","+p+")";
           
            cnx = connecterDB();
            st = cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("Personne bien ajouté");
            
        }
    catch( SQLException e){
            System.out.println(e.getMessage());
        }
    }
/**
 *@param id 
 *          id de l'eleve
 */ 
public void DeleteEleve(int id){
        try{
           String query="DELETE FROM ELEVE WHERE id="+id; 
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("Personne bien supprimé");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
/**
 *@param id 
 *          id de l'eleve
 * @param nom
 *          nom de l'eleve
 * @param prenom
 *          prenom de l'eleve
 */ 
public void UpdateEleve(int id,String nom,String prenom ){
       try{ 
           
          
           String query="UPDATE ELEVE SET Nom='"+nom+"', Prenom='"+prenom+"' WHERE ID="+id;
           System.out.println(query);
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("ELEVE bien modifié");
           
       }catch(SQLException e){
           System.out.println(e.getMessage());
       }
}

    /**
     *
     * @param id
     * id de l'eleve
     */
    public void RechercherEleve(int id){
    try{
        
        
        
            Vector a = new Vector();
            a.recherche_eleves(id);
        
       
        
    }catch(SQLException e){
        System.out.println(e.getMessage());
    }
       
       
   }

}
