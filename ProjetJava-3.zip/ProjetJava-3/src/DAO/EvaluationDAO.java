/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static Controleur.Connexion.cnx;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.st;
import java.sql.SQLException;

/**
 *
 * @author Lydia et Melissa
 */
public class EvaluationDAO {
    
    
    public EvaluationDAO()
    {};
    
    public  void CreateEvaluation(int id,int detailbulletin_id ,double note,String appreciation){
        try{
            String a = "'"+appreciation+"'";
            
            System.out.println(a);
            String query="INSERT INTO EVALUATION VALUES("+id+","+note+","+a+","+detailbulletin_id+")";
            cnx=connecterDB();
            st=cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("EVALUATION bien ajouté");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        
    }
/**
 *@param id 
 *          id de l'evaluation
 */ 
     public  void DeleteEvaluation(int id){
        try{
           String query="DELETE FROM EVALUATION WHERE id="+id; 
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("EVALUATION bien supprimé");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
     
     
     
 /**
 *@param id 
 *          id de l'eleve
 * @param id_detailbulletin
 *          id detail bulletin
 * @param note
 *          note de l'eleve
 * @param appreciation
 *          appreciation de l'eleve
 * @author Lydia et Mélissa
 */    
   public void UpdateEvaluation( int id,int id_detailbulletin, double note, String appreciation){
       try{
            System.out.println("cc");
        String a = "'"+appreciation+"'";
           
           String query="UPDATE EVALUATION SET note='"+note+"', id_detailbulletin='"+id_detailbulletin+"', appreciation="+a+" WHERE id="+id;
           cnx=connecterDB();
           st=cnx.createStatement();
           st.executeUpdate(query);
           System.out.println("Produit bien modifié");
           
       }catch(SQLException e){
           System.out.println(e.getMessage());
       }
       
       
   }
}
