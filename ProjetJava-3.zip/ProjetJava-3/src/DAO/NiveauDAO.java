/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static Controleur.Connexion.cnx;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.st;
import java.sql.SQLException;

/**
 *
 * @author lyly
 */
public class NiveauDAO {
    
    
    
    
    public NiveauDAO()
    {};
/**
 *@param id 
 *          id du niveau
 * @param nom
 *          nom du niveau
 * @author Lydia et Mélissa
 */ 
   public  void CreateNiveau(int id,String nom){
        try{
            String a = "'"+nom+"'";
            
            System.out.println(a);
            String query="INSERT INTO NIVEAU VALUES("+id+","+nom+")";
            cnx=connecterDB();
            st=cnx.createStatement();
            st.executeUpdate(query);
            System.out.println("NIVEAU bien ajouté");
            
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
        
    }
   
   
   
    
 
    
}
