/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;



import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javafx.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.awt.*;


public class Affichage extends JFrame implements ActionListener{
    
   
    private JPanel container = new JPanel(); //JPanel
    public JTextArea jta =new JTextArea();
    public JTextField jtf1=new JTextField();
    public JTextField jtf2=new JTextField();
    
    Button b = new Button("boutton");
    b.addActionListener(this);
    
    
    public Affichage(){
       
        this.setTitle("Inscription d'un eleve");
        this.setSize(800, 650);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public void Menu(){
        container.setLayout(new GridLayout(10,1)); //Layout : GridLayout
        JLabel label=new JLabel("Gestionnaire de portefeuille, que souhaitez-vous faire ?"); //JLabel
        JButton bouton2= new JButton("Sérialiser"); //JButton
        

        this.setContentPane(container);
        this.setVisible(true);
    }
    
    
    
    
    
    public void Afficher() {
        container.setLayout(new BorderLayout());

  
        
       
        
        //On ajoute un scrollpane afin de pouvoir faire défiler les informations sur le panel
        JScrollPane scrollPane = new JScrollPane(jta);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        //On ajoute le scrollpane au panel
        container.add(scrollPane,BorderLayout.CENTER);
        container.add(bouton,BorderLayout.SOUTH);       

        this.setContentPane(container);
        this.setVisible(true);
    }
    

    
    
    public static void main(String[] args) {
        Affichage a = new Affichage();
        
        a.Afficher();
        

     
    }

    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == "bouton") {
            //String data = txtdata.getText(); //perform your operation
            System.out.println("ca marche");
        }
    }

    
}


