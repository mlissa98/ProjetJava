/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controleur;

import static Controleur.Connexion.cnx;
import static Controleur.Connexion.connecterDB;
import static Controleur.Connexion.st;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author lyly
 */
public class Vector extends javax.swing.JFrame {

    /**
     * Creer un nouvel  Affichage des tables
     * @throws java.sql.SQLException
     */
    public Vector() throws SQLException {
        
    }
    
    /**
     * Affichage de la table eleves 
     */
    
    public void affiche_eleves ()
    {
        try {
            initComponents();
            String query="SELECT * FROM  ELEVE ";
            System.out.println(query);
            cnx=connecterDB();
            st=cnx.createStatement();
            ResultSet rs = st.executeQuery(query);
            Eleves.setModel(DbUtils.resultSetToTableModel(rs));
          
            this.setTitle("Tous les élèves de l'école");
            this.setSize(400,250);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Vector.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    
    public void recherche_eleves (int id)
    {
        try {
            initComponents();
            String query="SELECT * FROM  ELEVE  WHERE id="+id;
            System.out.println(query);
            cnx=connecterDB();
            st=cnx.createStatement();
            ResultSet rs = st.executeQuery(query);
            Eleves.setModel(DbUtils.resultSetToTableModel(rs));
            
            this.setTitle("Recherche d'eleves");
            this.setSize(400,250);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Vector.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    /**
     * Affichage de la table professeurs
     */
    
    public void affiche_professeurs  ()
    {
        try {
            initComponents();
            String query="SELECT * FROM  PERSONNE ";
            System.out.println(query);
            cnx=connecterDB();
            st=cnx.createStatement();
            ResultSet rs = st.executeQuery(query);
            Eleves.setModel(DbUtils.resultSetToTableModel(rs));
            
            this.setTitle("JTab Example");
            this.setSize(400,250);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Vector.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    /**
     * Affichage de la table des enseignements 
     */
    
    public void affiche_enseignements  ()
    {
        try {
            initComponents();
            String query="SELECT * FROM  ENSEIGNEMENT ";
            System.out.println(query);
            cnx=connecterDB();
            st=cnx.createStatement();
            ResultSet rs = st.executeQuery(query);
            Eleves.setModel(DbUtils.resultSetToTableModel(rs));
          
            this.setTitle("JTab Example");
            this.setSize(400,250);
            this.setLocationRelativeTo(null);
            this.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(Vector.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Eleves = new javax.swing.JTable();

        //setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Eleves.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Eleves);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        pack();
    }
    

    /**
     *Cette méthode sert à créer une table et à l'initialiser
     */
   /* @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Eleves = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Eleves.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Eleves);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vector.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Vector().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Vector.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Eleves;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
